package MyFile;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

import IteratorPattern.ConcreteAggregate;
import IteratorPattern.Iterator;
import IteratorPattern.Aggregate;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

//�ļ��Ի���
public class ImageFileChooser extends JFileChooser {

	//ʹ���û�Ĭ��·������һ��ImageFileChooser
	public ImageFileChooser() {
		super();
		setAcceptAllFileFilterUsed(false);
		addFilter();
	}

	//ʹ���Զ����·��·������һ��ImageFileChooser
	public ImageFileChooser(String currentDirectoryPath) {
		super(currentDirectoryPath);
		setAcceptAllFileFilterUsed(false);
		addFilter();
	}

	//��ȡ��׺��
	public String getSuf() {
		// ��ȡ�ļ����˶���
		FileFilter fileFilter = this.getFileFilter();
		String desc = fileFilter.getDescription();
		String[] sufarr = desc.split(" ");
		String suf = sufarr[0].equals("����ͼ���ļ�") ? "" : sufarr[0];
		return suf.toLowerCase();
	}

	//ʹ�õ�����ģʽ�����ļ�������
	private void addFilter() {
		Aggregate myList=new ConcreteAggregate();
		myList.add(new MyFileFilter(new String[] { ".BMP" }, "BMP (*.BMP)"));
		myList.add(new MyFileFilter(new String[] { ".GIF" }, "GIF (*.GIF)"));
		myList.add(new MyFileFilter(new String[] { ".TIF", ".TIFF" }, "TIFF (*.TIF;*.TIFF)"));
		myList.add(new MyFileFilter(new String[] { ".PNG" }, "PNG (*.PNG)"));
		myList.add(new MyFileFilter(new String[] { ".ICO" }, "ICO (*.ICO)"));
		myList.add(new MyFileFilter(new String[] { ".JPG", ".JPEG", ".JPE", ".JFIF" },
				"JPEG (*.JPG;*.JPEG;*.JPE;*.JFIF)"));
		myList.add(new MyFileFilter(new String[] { ".BMP", ".JPG", ".JPEG", ".JPE", ".JFIF", ".GIF", ".TIF", ".TIFF",
				".PNG", ".ICO" }, "����ͼ���ļ�"));
		Iterator it=myList.iterator();
		while(it.hasNext()){
			this.addChoosableFileFilter((MyFileFilter)it.next());
		}
	}
}