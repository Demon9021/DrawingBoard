package Action;

import MyFile.MyImageFile;
import StatePattern.*;

import javax.swing.*;

import Image.ImageFrame;
import MementoPattern.CareTaker;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

public class KeyboardListener extends JPanel implements KeyListener {

    public BufferedImage myImage;

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //����
        if (e.getKeyCode() == 90 && e.isControlDown()){
            System.out.println("");
            Undo();
        }
        //ɾ��
        else if (e.getKeyCode() == 89 && e.isControlDown()){
            Redo();
        }
        //����
        else if (e.getKeyCode() == 83 && e.isControlDown()){
            Save();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

   //����
    private void Undo(){
        ImageFrame.getInstance().originator.
                getStateFromMemento(ImageFrame.getInstance().careTaker.Undo());
        myImage = ImageFrame.getInstance().originator.getState();
        ImageFrame.getInstance().my_draw(myImage);
        if(CareTaker.getInstance().index != 0){
            MiddleState middleState = new MiddleState();
            middleState.doAction(ImageFrame.getInstance().context);
        }else {
            StartState startState = new StartState();
            startState.doAction(ImageFrame.getInstance().context);
        }
    }

    //����
    private void Redo(){
        ImageFrame.getInstance().originator.
                getStateFromMemento(ImageFrame.getInstance().careTaker.Redo());
        myImage = ImageFrame.getInstance().originator.getState();
        ImageFrame.getInstance().my_draw(myImage);
        if(CareTaker.getInstance().index != CareTaker.getInstance().size() - 1){
            MiddleState middleState = new MiddleState();
            middleState.doAction(ImageFrame.getInstance().context);
        }
        else {
            EndState endState = new EndState();
            endState.doAction(ImageFrame.getInstance().context);
        }
    }

   //����
    private void Save(){
        MyImageFile myImageFile = new MyImageFile();
        myImageFile.save(true, ImageFrame.getInstance());
    }
}
